#include <iostream>
using namespace std;


struct paciente{
  
private:
  string nome;
  string cpf;
  int dia = 0;
    int mes = 0;
    int ano = 0;
    int meses[12]={32,29,32,31,32,31,32,32,31,32,31,32};
    bool biss= false, ca=false,cm=false,cd=false;
public:

void verifica_a(int ano){
  
    if(ano>1900){
      this->ano=ano;   
      ca=true; 
      
    }else{
      cout<<"Ano inválido";
      
    }        
    
  }

  void verifica_m(int mes){
  
    if(mes>0 && mes<13){   
        this-> mes=mes;
        cm=true;
    }else{
        cout<<"Mês inválido"<<endl;
    }                 
          
         
    
  }
  void verifica_d(int dia){
            
            if(this->ano%4 == 0 && (this->ano%100 != 0 || this->ano%400 == 0))
                this->biss = true;
            else
                this->biss = false;
            
            if(this->mes == 2 && biss)
            {
                if(dia < ((meses[mes-1])+1) && dia > 0){
                    this->dia = dia;
                    cd=true;
                }else{
                    cout << "Dia inválido!" << endl;
                }  
            }else{
              
                if(dia < meses[mes-1] && dia > 0)
                {
                    cd=true;
                    this->dia = dia;
                }else
                {
                    cout << "Dia inválido!" << endl;
                }
            }
        }

        int dian(){
          return this->dia;
        }
        int mesn(){
          return this->mes;
        }   
        int anon(){
          return this->ano;
        }           

  void confere_nome(string nome){
    if(nome.length()>2 && nome.length()<30){
      this->nome = nome;
     
    }else{
      cout<<"Nome de paciente inválido!!"<<endl;
      
    }
  }
  string nomep(){

    return this->nome;
  }
  void confere_cpf(string cpf){
    if(cpf.length()==11){
      this->cpf=cpf;

    }else{
      cout<<"CPF inválido!"<<endl;


    }

  }

  string cpfp(){
    return this->cpf;
  }
  void cpf_v(string cpfv){
    this->cpf=cpfv;

  }
  string cpf_valido(){
    return this->cpf;
  }

void nascimento(){  
  cd=false,cm=false,ca=false;
  while(cd==false || cm==false || ca==false){ 
     
  cout<<"Digite o dia: ";
  cin>>dia;  
  cout<<"Digite o mês: ";
  cin>>mes;  
  cout<<"Digite o ano: ";
  cin>>ano;

  verifica_a(ano);
  verifica_m(mes);
  verifica_d(dia);

  }
 
  cd=false,cm=false,ca=false;

}


};
////////////////////////////////////////////////////////////MÉDICO/////////////////////////////////////////////////////////////////////////////////////
struct medico{
  string nome;
  string crm;
  string esp;

  void confere_nome(string nome){
    if(nome.length()>3 && nome.length()<30){
      this->nome = nome;
     
    }else{
      cout<<"Nome de médico inválido!!"<<endl;
      
    }
  }
  string nomem(){

    return this->nome;
  }
  void confere_crm(string crm){
    if(crm.length()==9){
      this->crm=crm;

    }else{
      cout<<"CRM inválido!"<<endl;
    }

  }

  string crmm(){
    return this->crm;
  }
  void crm_v(string crmv){
    this->crm=crmv;

  }
  string crm_valido(){
    return this->crm;
  }

  void confere_esp(string esp){
    this->esp=esp;
  }
  string espm(){
    return this->esp;
  }

};

////////////////////////////////////////////////////////////CONSULTA/////////////////////////////////////////////////////////////////////////////////////
struct consulta{

private:
string nomep, nomem,cpfc;
int hora, minuto, horaf, minutof;
int dia = 0;
    int mes = 0;
    int ano = 0;
    int meses[12]={32,29,32,31,32,31,32,32,31,32,31,32};
    bool biss= false;
    bool cd=false,cm=false,ca=false;
    bool ch=false,com=false,chf=false,comf=false;  
public:
void verifica_a(int ano){
 
    if(ano>1900){
      this->ano=ano;   
      ca=true;

    }else{
      cout<<"Ano inválido";
      
    }        
    
  }

  void verifica_m(int mes){
   
    if(mes>0 && mes<13){   
        this-> mes=mes;
        cm=true;
    }else{
        cout<<"Mês inválido"<<endl;
    }                 
          
         
    
  }
void verifica_d(int dia){
    
            if(this->ano%4 == 0 && (this->ano%100 != 0 || this->ano%400 == 0))
                this->biss = true;
            else
                this->biss = false;
            
            if(this->mes == 2 && biss)
            {
              
                if(dia < ((meses[mes-1])+1) && dia > 0){
                    this->dia = dia;
                    cd=true;
                  }else{

                  cout << "Dia inválido" << endl;
                }
                    
            }else{
                
                if(dia < meses[mes-1] && dia > 0)
                {
                    cd=true;
                    this->dia = dia;
                }else
                {
                    cout << "Dia inválido!" << endl;
                }
            }
        }

        int diac(){
          return this->dia;
        }
        int mesc(){
          return this->mes;
        }   
        int anoc(){
          return this->ano;
        }
void dconsulta(){
  
  while(cd==false||cm==false||ca==false){
  cd=false,cm=false,ca=false;  
  cout<<"Digite o dia: ";
  cin>>dia;  
  cout<<"Digite o mês: ";
  cin>>mes;  
  cout<<"Digite o ano: ";
  cin>>ano;

  verifica_a(ano);
  verifica_m(mes);
  verifica_d(dia);


  }
  cd=false,cm=false,ca=false;  
  
}

void h(int hora){
  
    if(hora >= 0 && hora <=24){
      this->hora = hora;
      ch=true;
    }else{  
      cout<<"Hora inválida \n";     

    }

  }

  void m(int minuto){
    
    if(minuto>=0 && minuto <60){
      this->minuto = minuto;
      com=true;
    }else{
      cout<<"Minuto inválido \n";

    }    

  }

  

  int retorna_hora(){
    return this->hora;
  }
  int retorna_minuto(){
    return this->minuto;
  }
  

  void horac(){
    ch=false,com=false;
    while(ch==false||com==false){
      
    cout<<"Digite as horas: ";
    cin>>hora;
    cout<<"Digite os minutos: ";
    cin>>minuto;
    h( hora);
    m(minuto);
    
    } 
    ch=false,com=false;   
  }
  void hf(int horaf){
  
    if(horaf >= 0 && horaf <=24){
      this->horaf = horaf;
      chf=true;
    }else{  
      cout<<"Hora inválida \n";     

    }

  }

  void mf(int minutof){
    
    if(minutof>=0 && minutof <60){
      this->minutof = minutof;
      comf=true;
    }else{
      cout<<"Minuto inválido \n";

    }    

  }
  int rhf(){
    return this->horaf;
  }
  int rmf(){
    return this->minutof;

  }
  void horafinal(){
    bool ch1=false,com1=false;
    while(ch1==false||com1==false){   

    cout<<"Digite a hora final da consulta: ";
    cin>>horaf;
    cout<<"Digite os minutos do final da consulta: ";
    cin>>minutof;
    if((horaf==this->hora && minutof==this->minuto) || horaf<this->hora ){
      cout<<"O horário não pode ser marcado, digite um horário válido!"<<endl;
      ch1=false;
      com1=false;
    }else{
      ch1=true;
      com1=true;
      hf(horaf);
      mf(minutof);
    }    
    
    }    
  }

  void cnomep(string nomep){
    this->nomep=nomep;
  }
  string rcnomep(){
    return this->nomep;
  }
  void cnomem(string nomem){
    this->nomem=nomem;
  }
  string rcnomem(){
    return this->nomem;
  }
  void cpf(string cpfc){
    this->cpfc=cpfc;

  }
  string ccpf(){
    return this->cpfc;

  }

};


int main() {
paciente p[2];
medico m[2];
consulta c[2];
int cont1=0, cont2=0, cont3=0;
string  nomep,nomem, cpf, crm, esp;

  cout<<"---------------------------------BEM VINDO---------------------------------" <<endl; 
  int opcao;
  
  while(opcao!=7){ 
    cout<<"O que deseja fazer? \n1-Cadastrar paciente\n2-Cadastrar médico\n3-Lista de pacientes\n4-Listar médicos\n5-Marcar consulta\n6-Exibir consulta\n7-SAIR"<<endl;
    cin>>opcao;  

    if(opcao==1){
      cout<<"---------------------------------CADASTRO DE PACIENTE---------------------------------" <<endl;
      bool  cn =false;
      while(cn==false){
      cout<<"Digite o nome do paciente: ";
      cin>>nomep;
        if(nomep.length()>2 && nomep.length()<31){
          p[cont1].confere_nome(nomep);
          cn=true;
        }else{
          cout<<"Nome inválido, por favor ";
        }
      }      
      bool cp=false;
      while(cp==false){
        cout<<"Digite o CPF do paciente(apenas números): ";
        cin>>cpf;
        if(cpf.length()>0 && cpf.length()<11){
          cout<<"CPF inválido, por favor ";
        }else{
          cp=true;
        }
      }         
      p[cont1].confere_cpf(cpf);
      cout<<"Digite a data de nacimento"<<endl;
      p[cont1].nascimento();
      for(int i=0;i<cont1;i++){
        if(p[i].cpfp()==cpf){
          cout<<"CPF já cadastrado!"<<endl;
          cont1--;
          break;
        }else{
          p[cont1].cpf_v(cpf);
        }
      }
      cont1++;

    }
    if(opcao==2){
      cout<<"---------------------------------CADASTRO DE MÉDICO---------------------------------" <<endl; 
      bool cnm=false;
      while(cnm==false){
      cout<<"Digite o nome do Médico: ";
      cin>>nomem;
        if(nomem.length()>2 && nomem.length()<31){
           m[cont2].confere_nome(nomem);
           cnm=true;
        }else{
          cout<<"Nome inválido, por favor ";
        }     

      }     
      
      bool cm =false;
      while(cm==false){
        cout<<"Digite o CMR do médico(apenas números): ";
        cin>>crm;
        if(crm.length()!=9){
          cout<<"CRM inválido por favor ";
        }else{
          m[cont2].confere_crm(crm);
          cm=true;
        }
      }   
      bool cesp=false;  
      while(cesp==false){
        cout<<"Digite a especialidade do médico: ";
        cin>>esp;
        if(esp.length()>2 && esp.length()<31){
          m[cont2].confere_esp(esp);
          cesp=true;
        }else{
          cout<<"Especialidade inválida, por favor ";
        }       
      }
     
      for(int i=0;i<cont2;i++){
        if(m[i].crmm()==crm){
          cout<<"CRM já cadastrado!"<<endl;
          cont2--;
          break;
        }else{
          m[cont2].crm_v(crm);
        }
      }

      cont2++;
    }
      if(opcao==3){
        cout<<"-------------------LISTA DE PACIENTES-------------------"<<endl;
        for(int i=0;i<cont1;i++){
          cout<<endl;
          cout<<"Nome do "<<i+1<<"°"<<" paciente: "<<p[i].nomep()<<endl;
          cout<<"CPF: "<<p[i].cpf_valido()<<endl;
          printf("Data de nascimento: %02d/%02d/%d\n ",p[i].dian(),p[i].mesn(),p[i].anon());
          cout<<endl; 
        }

      }
      if(opcao==4){
        cout<<"-------------------LISTA DE MÉDICOS-------------------"<<endl;
        for(int i=0;i<cont2;i++){
          cout<<endl;
          cout<<"Nome do "<<i+1<<"°"<<" médico: "<<m[i].nomem()<<endl;
          cout<<"CRM: "<<m[i].crm_valido()<<endl;
          cout<<"Especialidade: "<<m[i].espm()<<endl<<endl;
        }

      }
      if(opcao==5){
        cout<<"-------------------MARCAR CONSULTA-------------------"<<endl;
        cout<<"Digite o CPF do paciente(apenas números): "<<endl;
        cin>>cpf;
        cout<<"Digite o CRM do médico(apenas números): "<<endl;
        cin>>crm;
        cout<<"Data da consulta"<<endl;
        c[cont3].dconsulta();
        cout<<"Horário inicial da consulta"<<endl;
        c[cont3].horac(); 
        cout<<"Horário final da consulta"<<endl;
        c[cont3].horafinal();       
        for(int i=0;i<cont1;i++){
           if(cpf==p[i].cpf_valido()){
             c[cont3].cpf(cpf);
             c[cont3].cnomep(p[i].nomep());             
           }else if(cpf!=p[i].cpf_valido()&&i==cont1){
             cout<<"CPF do paciente não encontrado, o agendamento precisa ser refeito!"<<endl;
             cont3--;
           }            
        }
        for(int i=0;i<cont2;i++){
          if(crm==m[i].crm_valido()){
            c[cont3].cnomem(m[i].nomem());
            
          }else if(crm!=m[i].crm_valido() && i==cont2-1){
            cout<<"CRM do médico não foi encontrado, o agendamento precisa ser refeito!"<<endl;
            cont3--;
          }
        } 
        for(int i=0;i<cont3;i++){
          if(c[i].rcnomep()==c[cont3].rcnomep() && c[i].rcnomem()==c[cont3].rcnomem() && c[i].diac()==c[cont3].diac() && c[i].mesc()==c[cont3].mesc() && c   [i].anoc()==c[cont3].anoc() && c[i].retorna_hora()==c[cont3].retorna_hora() && c[i].retorna_minuto()==c[cont3].retorna_minuto()){
            cout<<"Esse paciente já tem uma consulta marcada nesse horário, com esse médico, por favor angende em outro dia!"<<endl;
            cont3--;
          }
        }
        for(int i=0;i<cont3;i++){
          if(c[i].rcnomem()==c[cont3].rcnomem() && c[i].diac()==c[cont3].diac() && c[i].mesc()==c[cont3].mesc() && c   [i].anoc()==c[cont3].anoc() && c[i].retorna_hora()==c[cont3].retorna_hora() && c[i].retorna_minuto()==c[cont3].retorna_minuto()){
            cout<<"Essemédico já tem uma consulta marcada nesse horário, por favor angende em outro dia!"<<endl;
            cont3--;
          }
        }

        cont3++;
      }
      if(opcao==6){
        cout<<"-------------------EXIBIR CONSULTA-------------------"<<endl;       
        cout<<"Digite o CPF do paciente (apenas números): ";
        cin>>cpf;
        bool ccp =false;
        for(int i=0;i<cont3;i++){
          if(cpf==c[i].ccpf()){
            cout<<"Nome do paciente: "<<c[i].rcnomep()<<endl;
            cout<<"Médico atendente: "<<c[i].rcnomem()<<endl;
            printf("Data da consulta: %02d/%02d/%d\n",c[i].diac(),c[i].mesc(),c[i].anoc());
            printf("Horário inicial da consulta: %02d:%02d:00\n",c[i].retorna_hora(),c[i].retorna_minuto());
            printf("Horário final da consulta:  %02d:%02d:00\n",c[i].rhf(),c[i].rmf());
            cout<<endl;
            ccp=true;
          }

        }
        if(ccp==false){
          cout<<"Consulta não encontrada, por favor agende uma consulta!"<<endl;
        }

      }

  }
    

}