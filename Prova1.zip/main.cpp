#include <iostream>
#include <cstring>
#include <string.h>

using namespace std;

struct aluno{
private: 
  int tamanho = 0, quantidade = 0;
  int dia=0, mes=0, ano=0;
  string nome;
  int meses[12]={32,29,32,31,32,31,32,32,31,32,31,32};
  bool biss= false,cd=false,cm=false,ca=false;
  public: 
/////////////////////////////////////////////////NOME////////////////////////////////////////////////////////////////////////////////////
  void verifica_nome(string nome){
    this->nome = nome;   

  }
  string nomea(){
    return this->nome;
  }
/////////////////////////////////////////////////CONFERE DATA////////////////////////////////////////////////////////////////////////////////////
 void verifica_a(int ano){
  
    if(ano>1900){
      this->ano=ano;   
      ca=true; 
      
    }else{
      cout<<"Ano inválido, insira a data novamente!"<<endl;
      
    }        
    
  }

  void verifica_m(int mes){
  
    if(mes>0 && mes<13){   
        this-> mes=mes;
        cm=true;
    }else{
        cout<<"Mês inválido, insira a data novamente"<<endl;
    }                 
          
         
    
  }
  void verifica_d(int dia){
            
            if(this->ano%4 == 0 && (this->ano%100 != 0 || this->ano%400 == 0))
                this->biss = true;
            else
                this->biss = false;
            
            if(this->mes == 2 && biss)
            {
                if(dia < ((meses[mes-1])+1) && dia > 0){
                    this->dia = dia;
                    cd=true;
                }else{
                    cout << "Dia inválido, insira a data novamente" << endl;
                }  
            }else{
              
                if(dia < meses[mes-1] && dia > 0)
                {
                    cd=true;
                    this->dia = dia;
                }else
                {
                    cout << "Dia inválido, insira a data novamente" << endl;
                }
            }
        }

        int dian(){
          return this->dia;
        }
        int mesn(){
          return this->mes;
        }   
        int anon(){
          return this->ano;
        }
/////////////////////////////////////////////////DATA DE NASCIMENTO////////////////////////////////////////////////////////////////////////////////////   
  void nascimento(){  
    cd=false,cm=false,ca=false;
    while(cd==false || cm==false || ca==false){ 
      
    cout<<"Digite o dia: ";
    cin>>dia;  
    cout<<"Digite o mês: ";
    cin>>mes;  
    cout<<"Digite o ano: ";
    cin>>ano;

    verifica_a(ano);
    verifica_m(mes);
    verifica_d(dia);

    }
 
    cd=false,cm=false,ca=false;

  }
  /////////////////////////////////////////////////INSERINDO ALUNO////////////////////////////////////////////////////////////////////////////////////

 
};
/////////////////////////////////////////////////LISTA////////////////////////////////////////////////////////////////////////////////////   
  struct v{
    private:     
    int tamanho = 0, tamanho1=0,tamanho2=0;
    int quantidade = 0,quantidade2=0,quantidade3=0;
    aluno *elementos = new aluno[tamanho];
    aluno *ordenado = new aluno[tamanho];
    aluno *crescente = new aluno[tamanho];
    
  public:    
    
    void inserir(aluno e){
      if(quantidade < tamanho){
        elementos[quantidade] = e;        
        quantidade++;
      }else{
        aluno *novo_vetor = new aluno[tamanho + 1];
        for (int i = 0; i<tamanho; i++){
          novo_vetor[i]=elementos[i];
          
        }
        tamanho++;
       
        elementos = novo_vetor;
        elementos[quantidade] = e;
        quantidade ++;
      }
      
      if(quantidade2 < tamanho1){        
        ordenado[quantidade2] = e;        
        quantidade2++;
      }else{
        aluno *novo_vetor1 = new aluno[tamanho1 + 1];
        for (int i = 0; i<tamanho1; i++){
          novo_vetor1[i]=ordenado[i];
          
        }
          tamanho1++;
          ordenado = novo_vetor1;
          ordenado[quantidade2]=e;
          quantidade2++; 
      }
      if(quantidade3 < tamanho2){        
        crescente[quantidade3] = e;        
        quantidade3++;
      }else{
        aluno *novo_vetor2 = new aluno[tamanho2 + 1];
        for (int i = 0; i<tamanho2; i++){
          novo_vetor2[i]=crescente[i];
          
        }
          tamanho2++;
          crescente = novo_vetor2;
          crescente[quantidade3]=e;
          quantidade3++; 
      }


    }
    
    void ordena1(){
      for(int j=0; j<tamanho;j++){       
        for(int i=j;i>0;i--){
          if(strcmp(elementos[i].nomea().c_str(), elementos[i-1].nomea().c_str())<0){
           aluno aux = elementos[i];
           elementos[i]=elementos[i-1];
           elementos[i-1] = aux;
            

          }else{
            break;
          }
        }         
      } 
      for (int i = 0; i<tamanho; i++){
        cout<<"Nome do "<<i+1<<"° aluno: "<<elementos[i].nomea()<<endl;
        printf("Data de nasimento: %02d/%02d/%d\n\n", elementos[i].dian(),elementos[i].mesn(),elementos[i].anon());
      } 

    }
    void cresce(){
      for(int j=0; j<tamanho2;j++){              
        for(int i=j;i>0;i--){
          if(crescente[i].anon()>crescente[i-1].anon()){
            aluno aux = crescente[i];
            crescente[i] = crescente[i-1];
            crescente[i-1]=aux;
            
          }else if(crescente[i].mesn()>crescente[i-1].mesn()&&crescente[i].anon()==crescente[i-1].anon()){
            aluno aux = crescente[i];
            crescente[i] = crescente[i-1];
            crescente[i-1]=aux;

          }else if(crescente[i].dian()>crescente[i-1].dian()&&crescente[i].mesn()==crescente[i-1].mesn()&&crescente[i].anon()==crescente[i-1].anon()){
            aluno aux = crescente[i];
            crescente[i] = crescente[i-1];
            crescente[i-1]=aux;
          }else{
            break;
          }
        }           
      }
       for (int i = 0; i<tamanho2; i++){
        cout<<"Nome do "<<i+1<<"° aluno: "<<crescente[i].nomea()<<endl;
        printf("Data de nasimento: %02d/%02d/%d\n\n", crescente[i].dian(),crescente[i].mesn(),crescente[i].anon());
      }    
    }
    void imprime(){
      for (int i = 0; i<tamanho; i++){
        cout<<"Nome do "<<i+1<<"° aluno: "<<ordenado[i].nomea()<<endl;
        printf("Data de nasimento: %02d/%02d/%d\n\n", ordenado[i].dian(),ordenado[i].mesn(),ordenado[i].anon());
      }
      
     
    }    

      
  };

  

int main() {
    aluno a;
    v lista;
    string nome;
    int opcao,escolha;
    bool cn=false;
    while(opcao !=3){
      cout<<"O que deseja fazer?\n1-Cadastrar aluno\n2-Listar\n3-SAIR\n";
      cin>>opcao;

      if(opcao==1){
        cout<<"---------------CADASTRAR ALUNOS---------------"<<endl;
        cn=false;
        while(cn==false){           
          cout<<"Digite o nome do aluno: ";
          cin>>nome;
          if(nome.length()<3 ||nome.length()>15){
            cout<<"Nome inválido, por favor ";
          }else{
            a.verifica_nome(nome);
            cn=true;            
          }
        }
        cout<<"Data de nascimento "<<endl;
        a.nascimento();
        lista.inserir(a);
      }
      if(opcao==2){
        cout<<"---------------LISTAR ALUNOS---------------"<<endl;
        cout<<"1-Listar por ordem de inserção\n2-Listar por ordem alfabética\n3-Listar por data de nascimento, do mais novo ao mais velho\n";
        cin>>escolha;
        if(escolha==1){
          lista.imprime();
        }
        if(escolha==2){
          lista.ordena1();
          
        }
        if(escolha ==3){
          lista.cresce();
        }
        
      }
    }
    
    

} 