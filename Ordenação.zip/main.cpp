#include <iostream>
#include <cstring>
#include <string.h>

using namespace std;

void imprime(string a[], int n){

  int n1;
  cout<<"Como deseja imprimir? 1 - A-Z, 2 - Z-A"<<endl;
  cin>>n1;
  if(n1==1){
    for(int j=0; j<n;j++){
   for(int i=j;i>0;i--){
      if(strcmp(a[i].c_str(), a[i-1].c_str())<0){
        string aux = a[i];
        a[i]=a[i-1];
        a[i-1]=aux;

      }else{
        break;
      } 
    }
  }
    for(int i=0; i<n;i++){
      cout<<i+1<<"° Nome: "<<a[i]<<endl;
    }
  }else if(n1==2){
    for(int j=0; j<n;j++){
   for(int i=j;i>0;i--){
      if(strcmp(a[i].c_str(), a[i-1].c_str())>0){
        string aux = a[i];
        a[i]=a[i-1];
        a[i-1]=aux;

      }else{
        break;
      } 
    }
  }
    for(int i=0; i<n;i++){      
      cout<<i+1<<"° Nome: "<<a[i]<<endl;
      
    }
  }else{
    cout<<"Escolha inválida!!"<<endl;
  }
}

int main() {
  int n=10;
  string nomes[n]; 
 
  for(int i=0; i<n;i++){
    cout<<"Digite o "<<i+1<<"° nome: "<<endl;
    cin>>nomes[i];
  }  
  
  imprime(nomes,n);
  
} 